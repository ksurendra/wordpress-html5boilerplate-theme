<?php
/**
 * This is the default-template when no default.html is added during the conversion.
 * To create your own default-template during the converison consult our documentation.
 *
 * Your front-page can be found from front-page.php
 */
?>
No default template has been added for this theme. <a href="https://html-to-wordpress.readme.io/docs/templates#section-default-template" target="_blank">Click here</a> to find out how to create a default template for the conversion.